title: 将本地项目上传到gitlab下
date: '2019-04-24 07:57:27'
updated: '2019-04-24 08:04:07'
tags: [gitlab]
permalink: /articles/2019/04/24/1556063847528.html
---
**1、安装git** [https://git-scm.com/downloads](https://git-scm.com/downloads)
**2、新建项目自行到网站新建**
**3、创建密钥**
桌面右键选择Git Bash Here
`cd ~/.ssh/    #如果提示 “ No such file or directory”，你可以手动的创建一个 .ssh文件夹即可
mkdir ~/.ssh`
配置全局的name和email，参照你创建的工程Git global setup

       git config --global user.name "AAAA"  
       git config --global user.email "XXXXX@XX.com"

生成key

     ssh-keygen -t rsa -C "XXXXX@XX.com"

最后生成两个文件：id_rsa和id_rsa.pub   #在C://用户/用户名/.SSH 目录下

把id_rsa.pub里的内容粘贴到gitlab密钥中

**4、上传项目**
右键要上传的项目，选择Git Bash Here

输入下面的命令

git config --global user.name "xx"
git config --global user.email "xxxxxx@xx.com"
git init
git remote add origin 项目地址
git add .
git commit -m "上传的文件夹"
git push -u origin master
