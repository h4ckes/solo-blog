title: Internet Download Manager 6.35老毛子版
date: '2019-09-05 07:45:41'
updated: '2019-09-05 07:45:41'
tags: [IDM]
permalink: /articles/2019/09/05/1567640740924.html
---

[下载地址](https://drive.cnci.xyz/%E8%BD%AF%E4%BB%B6/internet_download_manager_6.35.3.zip)

![QQ截图20190905074348.png](https://img.hacpai.com/file/2019/09/QQ截图20190905074348-2d08627f.png)


