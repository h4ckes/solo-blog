title: 为了方便开启自用win10 KMS 180天激活服务
date: '2019-03-22 08:34:19'
updated: '2019-04-15 13:54:19'
tags: [KMS]
permalink: /articles/2019/03/22/1553214859104.html
---
网上激活工具千千万99%里面不是有木马就是有广告推广
还是自己搭建的KMS服务靠谱
Windows各版本对应密钥：[https://docs.microsoft.com/zh-cn/windows-server/get-started/kmsclientkeys](https://docs.microsoft.com/zh-cn/windows-server/get-started/kmsclientkeys)

windows 10 ltsc下载地址：
[cn_windows_10_enterprise_ltsc_2019_x64](https://drive.cnci.xyz/MSDN/Windows%20Desktop/cn_windows_10_enterprise_ltsc_2019_x64_dvd_d17070a8.iso)
[cn_windows_10_enterprise_ltsc_2019_x86](https://drive.cnci.xyz/MSDN/Windows%20Desktop/cn_windows_10_enterprise_ltsc_2019_x86_dvd_62156a9a.iso)

如果你确定你是VOL版的，就不用更换密钥

slmgr /ipk 密钥

slmgr /skms www.cnci.xyz //设置KMS服务器

slmgr /ato //立即激活该系统

office激活自行网上找相关命令，本博主用的是office365