title: 金蝶FCustid修正
date: '2019-03-22 08:28:56'
updated: '2019-03-22 08:28:56'
tags: [金蝶]
permalink: /articles/2019/03/22/1553214536214.html
---
> --select *From ICTransactionType 
> --select FFieldName , *From ICClassLink where FSourClassTypeID = -81 and FDestClassTypeID = -28
> --select * from ICSelbills where FID = 'B08' and FFieldName = '81' and FDstCtlField = 'FEntrySelfB0861'
> 
> delete from ICSelbills where FID = 'B08' and FFieldName = '81'
> and FColName in('FCustID0','FCustID1','FCustID2')
> 
> update ICSelbills set FTableAlias = 'V1' 
> where FID = 'B08' and FFieldName = '81' and FDstCtlField = 'FEntrySelfB0861' 
> and FColName in('FCustIDName','FCustIDNumber')
> 
> update ICSelbills set FAction = '(SELECT FName FROM t_Organization WHERE FItemID = v1.FCustID)' 
> where FID = 'B08' and FFieldName = '81' and FDstCtlField = 'FEntrySelfB0861' 
> and FColName in('FCustIDName' ) 
> update ICSelbills set FAction = '(SELECT FNumber FROM t_Organization WHERE FItemID = v1.FCustID)' 
> where FID = 'B08' and FFieldName = '81' and FDstCtlField = 'FEntrySelfB0861' 
> and FColName in('FCustIDNumber' )