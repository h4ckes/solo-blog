title: B 站后端源码
date: '2019-04-23 08:33:12'
updated: '2019-06-07 09:56:32'
tags: [源码]
permalink: /articles/2019/04/23/1555979592662.html
---
代码貌似挺干净的，就是不知道有没有一些见不得人的业务
[下载地址](https://drive.cnci.xyz/Code/go-common-master.zip)
![QQ截图20190423082938.png](https://img.hacpai.com/file/2019/04/QQ截图20190423082938-169dac5c.png)
