title: Windows10 LTSC(2019,1809) 上安装 Windows Store/应用商店
date: '2019-03-22 08:35:38'
updated: '2019-06-07 09:55:39'
tags: [Windows]
permalink: /articles/2019/03/22/1553214937907.html
---
介绍

 Windows10 LTSB/C(长期服务版)是目前唯一使用得比较安心的Win10版本.
 但是LTSB/C也没了应用商店和UWP运行环境.

安装
 下载地址：[WindowsStore_LTSC2019exe](https://drive.cnci.xyz/%E8%BD%AF%E4%BB%B6/WindowsStore_LTSC2019.exe)
 
 该可执行文件为自解压文件，可解压自行查看源文件
 
卸载
> Get-AppxPackage Microsoft.XboxIdentityProvider  |Remove-AppxPackage
> 
> Get-AppxPackage Microsoft.StorePurchaseApp  |Remove-AppxPackage
> 
> Get-AppxPackage Microsoft.WindowsStore  |Remove-AppxPackage
> 
> Get-AppxPackage Microsoft.Advertising.Xaml  |Remove-AppxPackage
> 
> Get-AppxPackage Microsoft.VCLibs.140.00  |Remove-AppxPackage
> 
> Get-AppxPackage Microsoft.NET.Native.Framework.1.6  |Remove-AppxPackage
> 
> Get-AppxPackage Microsoft.NET.Native.Runtime.1.6  |Remove-AppxPackage