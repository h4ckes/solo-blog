title: 搭建solo
date: '2019-04-10 11:12:59'
updated: '2019-04-10 11:15:38'
tags: [solo]
permalink: /articles/2019/04/10/1554865979769.html
---
1、购买服务器，自行选购！
2、安装环境
**  2.1、安装JAVA：[https://www.cnci.xyz/articles/2019/03/22/1553214981570.html](https://www.cnci.xyz/articles/2019/03/22/1553214981570.html)

** 2.2、安装Nginx（如果这个都不会就不要搭建了）！

** 2.3、安装MySQL（如果这个都不会就不要搭建了）！

3、搭建solo
* * 3.1、创建数据库
`mysql  -u用户名  -p密码`
`CREATE DATABASE IF  NOT  EXISTS solo DEFAULT  CHARSET utf8 COLLATE utf8_general_ci;`
* * 3.2、修改Solo配置文件
下载最新war包：[https://github.com/b3log/solo/releases](https://github.com/b3log/solo/releases)
解压到网站目录：`jar  -xvf solo-2.9.1.war`
解压后，修改latke.properties文件
`vi solo/WEB-INF/classes/latke.properties`
`#### Server ####`
`# Browser visit protocol`
`serverScheme=https`
`#serverHost=你的域名`
`#serverPort=`
保存退出
修改local.properties文件
`vi  solo/WEB-INF/classes/local.properties`
`#### MySQL runtime ####`
`runtimeDatabase=MYSQL`
`jdbc.username=数据库用户名`
`jdbc.password=数据库密码`
`jdbc.driver=com.mysql.cj.jdbc.Driver`
`jdbc.URL=jdbc:mysql://localhost:3306/solo?useUnicode=yes&characterEncoding=UTF-8&useSSL=false&serverTimezone=UTC`
数据库名字与创建的数据库的名字要一样
保存退出
4、启动网站
`nohup  java  -cp  WEB-INF/lib/*:WEB-INF/classes org.b3log.solo.Starter  &`
* * 4.1、设置反向代理自行Google
5、登录博客后台设置网站信息