title: 基于Chromium的微软Edge浏览器完整安装包已经泄露
date: '2019-03-25 10:29:47'
updated: '2019-06-07 09:57:19'
tags: [Edge]
permalink: /articles/2019/03/25/1553480987737.html
---
微软即将推出的基于Chromium内核的Edge浏览器完整安装包已经在线泄露。浏览器的下载链接已发布到文件共享网站和热门的共享论坛。泄露的版本似乎是微软预计很快将在公开预览版中发布的早期版本。微软的新版Edge基于Chromium，早期版本包括Chrome扩展支持，收藏夹同步以及对用户界面的一些自定义调整。

泄露版Edge的开发完成度较高，在Windows 10上运行良好，但是，您可能会从Edge中看到一些还没有完工的地方。例如，微软尚未提供其预留选项卡功能，尚未实现使用手写笔功能的电子墨水特性，而黑暗模式目前只能通过手动打开测试标记获得，就像Google在Chrome中实现它一样。

另一方面，微软也正在开发适用于Mac的Edge版本，但目前尚不清楚它是否会与新版Edge for Windows版本同时亮相。

![QQ截图20190325075343.jpg](https://img.hacpai.com/file/2019/03/QQ截图20190325075343-31b62ede.jpg)


下载地址：https://drive.cnci.xyz/%E8%BD%AF%E4%BB%B6/microsoftedgesetup-latest.zip

官方正式版：[https://www.microsoftedgeinsider.com/en-us/](https://www.microsoftedgeinsider.com/en-us/)