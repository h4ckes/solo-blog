title: Java运行环境搭建
date: '2019-03-22 08:36:21'
updated: '2019-05-24 16:53:25'
tags: [Java]
permalink: /articles/2019/03/22/1553214981570.html
---
在Oracle官网[下载页面](http://www.yglong.com/wp-content/themes/Beginlts/inc/go.php?url=http://www.oracle.com/technetwork/java/javase/downloads/jdk8-downloads-2133151.html)下载Linux版的JDK压缩包,然后上传到服务器，（为什么不在服务器下载，因为有个接受许可协议和不接受许可协议，在服务器上直接用wget下载默认不接受许可协议，下载下来也没用）

> wget https://i.cnci.xyz/jdk-8u201-linux-x64.tar.gz

> tar  -zxvf jdk-8u201-linux-x64.tar.gz

接下来设置环境变量，用vi编辑器打开/etc/profile文件

> vi  /etc/profile

在文件开头添加如下内容（自行修改路径）：

   

```
JAVA_HOME=/www/server/java/jdk1.8.0_201

JRE_HOME=/www/server/java/jdk1.8.0_201/jre

PATH=$PATH:$JAVA_HOME/bin:$JRE_HOME/bin

CLASSPATH=.:$JAVA_HOME/lib/dt.jar:$JAVA_HOME/lib/tools.jar:$JRE_HOME/lib

export JAVA_HOME JRE_HOME PATH CLASSPATH
```

然后保存别执行以下命令使其生效：

> source  /etc/profile

最后在任意目录执行下面命令来测试Java是否安装成功：

> java  -version

如果你看到类似下面的输出，说明已经安装成功了：

> java version "1.8.0_201"
> Java(TM) SE Runtime Environment (build 1.8.0_201-b09)
> Java HotSpot(TM) 64-Bit Server VM (build 25.201-b09, mixed mode)
